package cn.edu.guet.dao.impl;

import cn.edu.guet.bean.Users;
import cn.edu.guet.dao.UserDao;

/**
 * @Author liwei
 * @Date 2023/5/16 20:27
 * @Version 1.0
 */
public class UserDaoImpl extends BaseDaoImpl<Users> implements UserDao{

}
