package cn.edu.guet.dao;

import cn.edu.guet.bean.Users;

/**
 * @Author liwei
 * @Date 2023/5/16 20:26
 * @Version 1.0
 */
public interface UserDao extends BaseDao<Users>{
}
